const express = require("express");
const authController = require("./../controllers/authController");
const blogController = require("./../controllers/blogController");
const router = express.Router();

router
  .route("/")
  .get(authController.protect, blogController.getAllBlogs)
  .post(blogController.createBlog);
router
  .route("/:id")
  .get(blogController.getOneBlog)
  .patch(blogController.updateBlog)
  .delete(blogController.deleteBlog);

module.exports = router;

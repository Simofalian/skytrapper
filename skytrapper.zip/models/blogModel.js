const mongoose = require("mongoose");

const reviewSchema = mongoose.Schema(
  {
    name: { type: String, required: true },
    rating: { type: Number, required: true },
    comment: { type: String, required: true },
  },
  { timestamps: true }
);
const blogSchema = mongoose.Schema(
  {
    title: {
      type: String,
      unique: true,
      required: [true, "must have a title"],
    },
    snippet: {
      type: String,
      trim: true,
      required: [true, "must have a title"],
    },
    body: {
      type: String,
      trim: true,
      required: [true, "must have a title"],
    },

    slug: String,
    createdAt: {
      type: Date,
      default: Date.now(),
      select: false,
    },

    category: {
      type: String,
      required: true,
      default: "relationship",
    },
    rating: { type: Number, required: true, default: 1 },
    reviews: [reviewSchema],
    numReviews: {
      type: Number,
      required: true,
      default: 2,
    },
  },
  { timestamps: true }
);

const Blog = mongoose.model("Blog", blogSchema);
module.exports = Blog;

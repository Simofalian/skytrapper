const catchAsync = require("./../Utils/catchAsync");
exports.getAllBlogs = (Model) => {
  catchAsync(async (req, res, next) => {});
};
